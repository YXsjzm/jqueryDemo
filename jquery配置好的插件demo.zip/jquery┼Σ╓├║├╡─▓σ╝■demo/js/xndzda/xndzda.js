$(function(){
    page();
    addIndor();
    deleteINfor();
    updateDeleteFriend();
    updateDeleteMroeFriend();
    updateUpdateFriend();
    updateUpdateMoreFriend();
    updateInfor();  
    deleteBq();
    findInfor();
    updateAddFriend();
    updateAddMoreFriend();
    addBqInfor();
    //主界面标签（调树结构）
    $(document).ready(function(){
        $.fn.zTree.init($("#treeDemo"), setting, zNodes);
    });
});
//修改弹框主界面
var updateInfor=function () {
    $(document).off('click','.updateInfor').on('click','.updateInfor',function(){
        var d = dialog({
            title: '虚拟身份-修改',
            content: `<div class="con updateConInfor" style="width: 1000px;height:900px;">
                       <form id="addInfor">
                            <header>基本信息</header>
                            <div class="col3-1 grey">
                               <div class="title grey"><span class="btx">*</span>姓名</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">证件类型</div>
                                 <select class="select-content" >
                                     <option value="1">身份证</option>
                                 </select>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">证件号码</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">ICP服务提供商</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">管辖地网安部门</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">注册账号类型</div>
                                <select class="select-content" >
                                     <option value="1">身份证</option>
                                 </select>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title grey">注册账号</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">账号昵称</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">注册时间</div>
                                <div class="jeinpbox">
		                             <input type="text" class="jeinput calendar4 input-content" placeholder="请选择时间">		                         
		                        </div>
                            </div>
                            <div class="col3-1">
                               <div class="title">注册IP地址</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">注册服务项目</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">数据来源名称</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1 grey">
                               <div class="title grey">首次采集时间</div>
                                 <div class="jeinpbox">
		                             <input type="text" class="jeinput calendar5 input-content" placeholder="请选择时间">		                         
		                        </div>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">最近采集时间</div>
                                 <div class="jeinpbox">
		                             <input type="text" class="jeinput calendar6 input-content" placeholder="请选择时间">		                         
		                        </div>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">累计发现次数</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">累计发现天数</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">新增发现次数</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">新增发现天数</div>
                                <input class="input-content" value="" name="" >
                            </div>
                             <div class="col3-1 grey">
                               <div class="title">敏感级别</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">采集地</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1 grey"></div>
                            <div class="yz"><img src="../../images/common/warn.png"/>"姓名"不能为空</div>
                                                                                  
                            <header style="margin-top: 20px;border: none;">标签 
                                <div class="addbq"><span class="icon-plus" style="font-weight: bold;"></span>添加标签</div>
                            </header>                          
                            <div class="bqCon">                              
                            </div>
                            
                            <header style="margin-top: 20px;border: none;">好友信息 
                                <div class="addfriend"><span class="icon-plus" style="font-weight: bold;"></span>添加好友信息</div>
                            </header>
                            <div class="tablediv" style="width: 100%;">
                              <table class="table table-hover updateTable">
                                  <thead>
                                  <tr>
                                      <th>序号</th>
                                      <th>好友关系类型</th>
                                      <th>身份类型</th>
                                      <th>好友账号</th>
                                      <th>好友用户ID</th>
                                      <th>操作</th>
                                  </tr>
                                  </thead>
                                  <tbody>
                                       <tr>
                                           <td>1</td>
                                           <td>股东会领导</td>
                                           <td>团员</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                           <td class="tdOption"><div class="icon-bin  update_deleteFriend" title="删除"></div><div class="icon-pencil update_updateFriend" title="修改"></div></td>
                                       </tr>
                                       <tr>
                                           <td>1</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                           <td class="tdOption"><div class="icon-bin  update_deleteFriend" title="删除"></div><div class="icon-pencil update_updateFriend" title="修改"></div></td>
                                       </tr>
                
                                  </tbody>
                              </table>
                          </div>
                          
                          
                          <header style="margin-top: 20px;border: none;">群组信息 
                                <div class="addMoreFriend"><span class="icon-plus" style="font-weight: bold;"></span>添加群组信息</div>
                          </header>
                            <div class="tablediv" style="width: 100%;">
                              <table class="table table-hover updateTable">
                                  <thead>
                                  <tr>
                                      <th>序号</th>
                                      <th>组织的网络类型</th>
                                      <th>组织的社会类型</th>
                                      <th>群组名称</th>
                                      <th>群号</th>
                                      <th>操作</th>
                                  </tr>
                                  </thead>
                                  <tbody>
                                       <tr>
                                           <td>1</td>
                                           <td>股东会领导</td>
                                           <td>团员</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                           <td class="tdOption"><div class="icon-bin update_deleteMroeFriend" title="删除"></div><div class="icon-pencil update_updateMoreFriend" title="修改"></div></td>
                                       </tr>
                                       <tr>
                                           <td>1</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                           <td class="tdOption"><div class="icon-bin update_deleteMroeFriend" title="删除"></div><div class="icon-pencil update_updateMoreFriend" title="修改"></div></td>
                                       </tr>
                
                                  </tbody>
                              </table>
                          </div>
                        
                      </form>
                  </div>`,
            okValue: '确 定',
            ok: function() {

            },
            cancelValue: '取 消',
            cancel: function() {}
        });
        d.showModal();
        canlendar();

    });
}
//虚拟身份修改--标签添加
var addBqInfor=function(){
    $(document).off('click','.addbq').on('click','.addbq',function(){
        var d = dialog({
            title: '标签库',
            content: `<div class="con" style="width: 300px;height: 330px;overflow-y: auto;">
                          <div id="menuContent_bqk" class="menuContent_bqk" position: absolute;">
                              <ul id="treeDemo_bqk" class="ztree" style="margin-top:0; width:180px; height: 300px;"></ul>
                          </div>                        
                     </div>`,
            okValue: '保 存',
            ok: function() {
               $(".bqCon").append(htmlBq);
            },
            cancelValue: '取 消',
            cancel: function() {}
        });
        d.showModal();
        $(document).ready(function(){
            $.fn.zTree.init($("#treeDemo_bqk"), setting_bqk, zNodes_bqk);
        });
    })
}
//虚拟身份修改--标签库树结构
var setting_bqk = {
    check: {
        enable: true,
        chkboxType: {"Y":"", "N":""}
    },
    view: {
        dblClickExpand: false
    },
    data: {
        simpleData: {
            enable: true
        }
    },
    callback: {
        beforeClick: beforeClick_bqk,
        onCheck: onCheck_bqk
    }
};
var zNodes_bqk =[
    { id:1, pId:0, name:"标签库", open:true,nocheck:true},
    { id:11, pId:1, name:"疑似防回流人员"},
    { id:12, pId:1, name:"失轨人员"},
    { id:13, pId:1, name:"可疑人员"},
    { id:14, pId:1, name:"普通人员"},
    { id:15, pId:1, name:"涉恐重点人员"},
    { id:16, pId:1, name:"重点关注人员", open:true,nocheck:true},
    { id:161, pId:16, name:"一级重点人员"},
    { id:162, pId:16, name:"二级重点人员"}
];
function beforeClick_bqk(treeId, treeNode) {
    var zTree = $.fn.zTree.getZTreeObj("treeDemo_bqk");
    zTree.checkNode(treeNode, !treeNode.checked, null, true);
    return false;
}
var htmlBq="";
function onCheck_bqk(e, treeId, treeNode) {
    var zTree = $.fn.zTree.getZTreeObj("treeDemo_bqk"),
        nodes = zTree.getCheckedNodes(true),
        v = "";
    console.log(nodes);
    htmlBq="";
    for (var i=0, l=nodes.length; i<l; i++) {
        htmlBq+='<div class="bqSelectCon"><span class="icon-tag">'+nodes[i].name+'</sapn><div class="icon-times deleteBq"></div></div>';
        v += nodes[i].name + ",";
    }
    if (v.length > 0 ) v = v.substring(0, v.length-1);
    console.log(v);
}
//虚拟身份修改--好友添加
var updateAddFriend=function(){
    $(document).off('click','.addfriend').on('click','.addfriend',function(){
        var d = dialog({
            title: '好友信息-添加',
            content: `<div class="con" style="width: 700px;height:220px;">
                       <form id="friendAdd">
                            <header>基本信息</header>
                            <div class="col2-1 grey">
                               <div class="title grey">好友关系类型</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col2-1 grey">
                               <div class="title">身份类型</div>
                                 <input class="input-content" value="" name="" >
                            </div>
                            <div class="col2-1">
                               <div class="title">好友账号</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col2-1">
                               <div class="title">好友用户ID</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col2-1 grey">
                               <div class="title">好友昵称</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col2-1 grey">
                               <div class="title">网络应用代码</div>
                               <input class="input-content" value="" name="" >

                            </div>
                            <div class="col2-1 ">
                               <div class="title grey">提取来源</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col2-1 grey">
                               <div class="title">管辖地网安部</div>
                                <input class="input-content" value="" name="" >
                            </div>                          
                          
                      </form>
                  </div>`,
            okValue: '确 定',
            ok: function() {

            },
            cancelValue: '取 消',
            cancel: function() {}
        });
        d.showModal();
    })
}
//虚拟身份修改--群组添加
var updateAddMoreFriend=function(){
    $(document).off('click','.addMoreFriend').on('click','.addMoreFriend',function(){
        var d = dialog({
            title: '群组信息-添加',
            content: `<div class="con" style="width: 700px;height:140px;">
                       <form id="moreFriendAdd">
                            <header>基本信息</header>
                            <div class="col2-1 grey">
                               <div class="title grey">组织网络类型</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col2-1 grey">
                               <div class="title">组织社会类型</div>
                                 <input class="input-content" value="" name="" >
                            </div>
                            <div class="col2-1">
                               <div class="title">群组名称</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col2-1">
                               <div class="title">群号</div>
                                <input class="input-content" value="" name="" >
                            </div>                                                                      
                      </form>
                  </div>`,
            okValue: '确 定',
            ok: function() {

            },
            cancelValue: '取 消',
            cancel: function() {}
        });
        d.showModal();

    })

}
//虚拟身份修改--好友修改
var updateUpdateFriend=function(){
    $(document).off('click','.update_updateFriend').on('click','.update_updateFriend',function(){
        var d = dialog({
            title: '好友信息-修改',
            content: `<div class="con" style="width: 700px;height:220px;">
                       <form id="friendUpdate">
                            <header>基本信息</header>
                            <div class="col2-1 grey">
                               <div class="title grey">好友关系类型</div>
                                <input class="input-content" value="111" name="" >
                            </div>
                            <div class="col2-1 grey">
                               <div class="title">身份类型</div>
                                 <input class="input-content" value="2222" name="" >
                            </div>
                            <div class="col2-1">
                               <div class="title">好友账号</div>
                                <input class="input-content" value="333" name="" >
                            </div>
                            <div class="col2-1">
                               <div class="title">好友用户ID</div>
                                <input class="input-content" value="444" name="" >
                            </div>
                            <div class="col2-1 grey">
                               <div class="title">好友昵称</div>
                                <input class="input-content" value="55" name="" >
                            </div>
                            <div class="col2-1 grey">
                               <div class="title">网络应用代码</div>
                               <input class="input-content" value="66" name="" >

                            </div>
                            <div class="col2-1 ">
                               <div class="title grey">提取来源</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col2-1 grey">
                               <div class="title">管辖地网安部</div>
                                <input class="input-content" value="" name="" >
                            </div>                          
                          
                      </form>
                  </div>`,
            okValue: '确 定',
            ok: function() {

            },
            cancelValue: '取 消',
            cancel: function() {}
        });
        d.showModal();
    })
};
//虚拟身份修改--群组修改
var updateUpdateMoreFriend=function(){
    $(document).off('click','.update_updateMoreFriend').on('click','.update_updateMoreFriend',function(){
        var d = dialog({
            title: '群组信息-修改',
            content: `<div class="con" style="width: 700px;height:140px;">
                       <form id="moreFriendUpdate">
                            <header>基本信息</header>
                            <div class="col2-1 grey">
                               <div class="title grey">组织网络类型</div>
                                <input class="input-content" value="111" name="" >
                            </div>
                            <div class="col2-1 grey">
                               <div class="title">组织社会类型</div>
                                 <input class="input-content" value="2222" name="" >
                            </div>
                            <div class="col2-1">
                               <div class="title">群组名称</div>
                                <input class="input-content" value="333" name="" >
                            </div>
                            <div class="col2-1">
                               <div class="title">群号</div>
                                <input class="input-content" value="444" name="" >
                            </div>                                                                      
                      </form>
                  </div>`,
            okValue: '确 定',
            ok: function() {

            },
            cancelValue: '取 消',
            cancel: function() {}
        });
        d.showModal();
    })
};
//查看弹框
var findInfor=function () {
    $(document).off('click','.findInfor').on('click','.findInfor',function(){
        var d = dialog({
            title: '虚拟身份-查看',
            content: `<div class="con findConInfor" style="width: 1000px;height:900px;">
                       <form id="addInfor">
                            <header>基本信息</header>
                            <div class="col3-1 grey">
                               <div class="title grey">姓名</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">证件类型</div>
                                 <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">证件号码</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1">
                               <div class="title">ICP服务提供商</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1">
                               <div class="title">管辖地网安部门</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1">
                               <div class="title">注册账号类型</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title grey">注册账号</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">账号昵称</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">注册时间</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1">
                               <div class="title">注册IP地址</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1">
                               <div class="title">注册服务项目</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1">
                               <div class="title">数据来源名称</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title grey">首次采集时间</div>
                                 <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">最近采集时间</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">累计发现次数</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1">
                               <div class="title">累计发现天数</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1">
                               <div class="title">新增发现次数</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1">
                               <div class="title">新增发现天数</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                             <div class="col3-1 grey">
                               <div class="title">敏感级别</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">采集地</div>
                                <input class="input-content" value="" name="" disabled>
                            </div>
                            <div class="col3-1 grey"></div>
                                                                                  
                            <header style="margin-top: 20px;border: none;">标签 </header>                          
                            <div class="bqCon">
                                <div class="bqSelectCon"><span class="icon-tag">普通人员</sapn></div>
                                <div class="bqSelectCon"><span class="icon-tag">白名单</sapn></div>                          
                            </div>
                            
                            <header style="margin-top: 20px;border: none;">好友信息 </header>
                            <div class="tablediv" style="width: 100%;">
                              <table class="table table-hover updateTable">
                                  <thead>
                                  <tr>
                                      <th>序号</th>
                                      <th>好友关系类型</th>
                                      <th>身份类型</th>
                                      <th>好友账号</th>
                                      <th>好友用户ID</th>
                                  </tr>
                                  </thead>
                                  <tbody>
                                       <tr>
                                           <td>1</td>
                                           <td>股东会领导</td>
                                           <td>团员</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                       </tr>
                                       <tr>
                                           <td>1</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                       </tr>
                
                                  </tbody>
                              </table>
                          </div>
                          
                          
                          <header style="margin-top: 20px;border: none;">群组信息 
                          </header>
                            <div class="tablediv" style="width: 100%;">
                              <table class="table table-hover updateTable">
                                  <thead>
                                  <tr>
                                      <th>序号</th>
                                      <th>组织的网络类型</th>
                                      <th>组织的社会类型</th>
                                      <th>群组名称</th>
                                      <th>群号</th>
                                  </tr>
                                  </thead>
                                  <tbody>
                                       <tr>
                                           <td>1</td>
                                           <td>股东会领导</td>
                                           <td>团员</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                       </tr>
                                       <tr>
                                           <td>1</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                           <td>序号</td>
                                       </tr>
                
                                  </tbody>
                              </table>
                          </div>
                        
                      </form>
                  </div>`,

            cancelValue: '关 闭',
            cancel: function() {}
        });
        d.showModal();
        canlendar();

    });
}
//删除标签
var deleteBq=function(){
    $(document).off('click','.updateConInfor .deleteBq').on('click','.updateConInfor .deleteBq',function(){
         $(this).parent().parent().remove();
    })

}
//修改弹框---删除好友
var updateDeleteFriend=function(){
    $(document).off('click','.update_deleteFriend').on('click','.update_deleteFriend',function(){
        var d = dialog({
            title: '删除好友',
            content: `<div class="con">
                          <img src="../../images/common/warn.png" style="width: 30px;margin-right: 20px;"/>
                          确定要删除"王大"信息吗？	
                      </div>`,
            okValue: '确 定',
            ok: function() {
                return false;
            },
            cancelValue: '取 消',
            cancel: function() {}
        });
        d.showModal();
        $(".ui-dialog-body").css({"width":"400px","height":"100px","color":"#717172"});
    })

}
//修改弹框---删除群组
var updateDeleteMroeFriend=function(){
    $(document).off('click','.update_deleteMroeFriend').on('click','.update_deleteMroeFriend',function(){
        var d = dialog({
            title: '删除群组',
            content: `<div class="con">
                          <img src="../../images/common/warn.png" style="width: 30px;margin-right: 20px;"/>
                          确定要删除"王大"信息吗？	
                      </div>`,
            okValue: '确 定',
            ok: function() {
                return false;
            },
            cancelValue: '取 消',
            cancel: function() {}
        });
        d.showModal();
        $(".ui-dialog-body").css({"width":"400px","height":"100px","color":"#717172"});
    })

}
//主界面表格删除
var deleteINfor=function(){
    $(document).off('click','.deletenfor').on('click','.deletenfor',function(){
        var d = dialog({
            title: '操作提示',
            content: `<div class="con">
                          <img src="../../images/common/warn.png" style="width: 30px;margin-right: 20px;"/>
                          确定要删除"王大"信息吗？	
                      </div>`,
            okValue: '确 定',
            ok: function() {
                return false;
            },
            cancelValue: '取 消',
            cancel: function() {}
        });
        d.showModal();
        $(".ui-dialog-body").css({"width":"400px","height":"100px","color":"#717172"});
    })
}
//主界面添加
var addIndor=function(){
    $('.addInfor').on('click', function() {
        var d = dialog({
            title: '虚拟身份-添加',
            content: `<div class="con" style="width: 1000px;height:320px;">
                       <form id="addInfor">
                            <header>基本信息</header>
                            <div class="col3-1 grey">
                               <div class="title grey"><span class="btx">*</span>姓名</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">证件类型</div>
                                 <select class="select-content" >
                                     <option value="1">身份证</option>
                                 </select>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">证件号码</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">ICP服务提供商</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">管辖地网安部门</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">注册账号类型</div>
                                <select class="select-content" >
                                     <option value="1">身份证</option>
                                 </select>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title grey">注册账号</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">账号昵称</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">注册时间</div>
                                <div class="jeinpbox">
		                             <input type="text" class="jeinput calendar1 input-content" placeholder="请选择时间">		                         
		                        </div>
                            </div>
                            <div class="col3-1">
                               <div class="title">注册IP地址</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">注册服务项目</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">数据来源名称</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1 grey">
                               <div class="title grey">首次采集时间</div>
                                 <div class="jeinpbox">
		                             <input type="text" class="jeinput calendar2 input-content" placeholder="请选择时间">		                         
		                        </div>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">最近采集时间</div>
                                 <div class="jeinpbox">
		                             <input type="text" class="jeinput calendar3 input-content" placeholder="请选择时间">		                         
		                        </div>
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">累计发现次数</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">累计发现天数</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">新增发现次数</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1">
                               <div class="title">新增发现天数</div>
                                <input class="input-content" value="" name="" >
                            </div>
                             <div class="col3-1 grey">
                               <div class="title">敏感级别</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1 grey">
                               <div class="title">采集地</div>
                                <input class="input-content" value="" name="" >
                            </div>
                            <div class="col3-1 grey"></div>
                            <div class="yz"><img src="../../images/common/warn.png"/>"姓名"不能为空</div>
                          
                      </form>
                  </div>`,
            okValue: '确 定',
            ok: function() {

            },
            cancelValue: '取 消',
            cancel: function() {}
        });
        d.showModal();
        canlendar();

    });
}
//日历
var canlendar=function(){
    $(".calendar1").jeDate({
        format: "YYYY-MM-DD hh:mm:ss"
    });
    $(".calendar2").jeDate({
        format: "YYYY-MM-DD hh:mm:ss"
    });
    $(".calendar3").jeDate({
        format: "YYYY-MM-DD hh:mm:ss"
    });
    $(".calendar4").jeDate({
        format: "YYYY-MM-DD hh:mm:ss"
    });
    $(".calendar5").jeDate({
        format: "YYYY-MM-DD hh:mm:ss"
    });
    $(".calendar6").jeDate({
        format: "YYYY-MM-DD hh:mm:ss"
    });
};
//主界面标签树结构
var setting = {
    check: {
        enable: true,
        chkboxType: {"Y":"", "N":""}
    },
    view: {
        dblClickExpand: false
    },
    data: {
        simpleData: {
            enable: true
        }
    },
    callback: {
        beforeClick: beforeClick,
        onCheck: onCheck
    }
};
var zNodes =[
    {id:1, pId:0, name:"北京"},
    {id:2, pId:0, name:"天津"},
    {id:3, pId:0, name:"上海"},
    {id:6, pId:0, name:"重庆"},
    {id:4, pId:0, name:"河北省", open:true, nocheck:true},
    {id:41, pId:4, name:"石家庄"},
    {id:42, pId:4, name:"保定"},
    {id:43, pId:4, name:"邯郸"},
    {id:44, pId:4, name:"承德"},
    {id:5, pId:0, name:"广东省", open:true, nocheck:true},
    {id:51, pId:5, name:"广州"},
    {id:52, pId:5, name:"深圳"},
    {id:53, pId:5, name:"东莞"},
    {id:54, pId:5, name:"佛山"},
    {id:6, pId:0, name:"福建省", open:true, nocheck:true},
    {id:61, pId:6, name:"福州"},
    {id:62, pId:6, name:"厦门"},
    {id:63, pId:6, name:"泉州"},
    {id:64, pId:6, name:"三明"}
];
function beforeClick(treeId, treeNode) {
    var zTree = $.fn.zTree.getZTreeObj("treeDemo");
    zTree.checkNode(treeNode, !treeNode.checked, null, true);
    return false;
}
function onCheck(e, treeId, treeNode) {
    var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
        nodes = zTree.getCheckedNodes(true),
        v = "";
    for (var i=0, l=nodes.length; i<l; i++) {
        v += nodes[i].name + ",";
    }
    if (v.length > 0 ) v = v.substring(0, v.length-1);
    var cityObj = $("#citySel");
    cityObj.attr("value", v);
}
function showMenu() {
    var cityObj = $("#citySel");
    var cityOffset = $("#citySel").offset();
    $("#menuContent").css({left:cityOffset.left + "px", top:cityOffset.top + cityObj.outerHeight() + "px"}).slideDown("fast");

    $("body").bind("mousedown", onBodyDown);
}
function hideMenu() {
    $("#menuContent").fadeOut("fast");
    $("body").unbind("mousedown", onBodyDown);
}
function onBodyDown(event) {
    if (!(event.target.id == "menuBtn" || event.target.id == "citySel" || event.target.id == "menuContent" || $(event.target).parents("#menuContent").length>0)) {
        hideMenu();
    }
}

//分页
var page=function(pagenum){
    Page({
        num: 20, //页码数
        startnum: 3, //指定页码
        elem: $('.pageStyle #page2'), //指定的元素
        callback: function(n) { //回调函数
         /*   pagenow=n;
            $('.gkgzclicksure').click();*/
        }
    });
};
